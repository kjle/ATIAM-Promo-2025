function [tout]=spectrogram_entier(u,nb,N,M,Fe)
% Tous les nb �chantillons nous extrayons une fen�tre de taille N dont nous
% calculons la TFD d'ordre M (apr�s fen�trage par hamming). Le r�sultat est
% affiche dans les colonne. L'affichage a besoin de la fr�quence
% d'�chantillonnage Fe.

t=0:N-1;
w=0.54-0.46*cos(2*pi*t/(N-1));

for n=1:nb:length(u)-N
    mu=u(n+1:n+N);% morceau de u � traiter (w non nul)
    mu=mu(:)'; %s'assurer que l'on a une ligne
    x=mu.*w; %signal dont il faut prendre la TFD d'ordre M
    tmp=abs(fft(x,M));
    tout(:,floor((n-1)/nb)+1)=tmp(1:M/2+1);
end

temps=(0:size(tout,2)-1)*nb*(1/Fe);
freq=(0:M/2)/M*Fe;
imagesc(temps,freq,log(tout));
