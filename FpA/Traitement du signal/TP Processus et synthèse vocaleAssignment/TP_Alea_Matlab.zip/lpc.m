function [out,res]=lpc(signal,p,nb)
% Renvoie un tableau dont chaque ligne est le meilleur pr�dicteur 
%lin�aire � p coefficients pour chaque morceau de nb �chantillons du signal
% Le nombre de colonnes de out est donc, approximativement length (out)/nb
%renvoie dans res l'�cart-type du r�sidu

signal=filter([1 -0.95],1,signal);
long=length(signal);
out=zeros(ceil(long/nb),p+1);
res=zeros(ceil(long/nb),1);
matx=zeros(p+1,nb+p);%matrice contenant le morceau de signal et ses d�cal�s

for k=1:nb:length(signal)
    
    % D'abord on sxtrait un morceau de signal
    if k+nb-1<=long
        tmp=signal(k:k+nb-1);
        tmp=tmp(:);tmp=tmp';% on s'assure que tmp est une ligne
    else
        tmp=signal(k:long);
        tmp=tmp(:); tmp=tmp';
        tmp=[tmp,zeros(1,nb-(long-k+1))]; %on compl�te pour avoir la bonne taille
    end
    %On appelle le programme lpc_morceau
    h=lpc_morceau(p,tmp);
    out(floor((k-1)/nb)+1,:)=h;
    epsilon=filter(h,1,tmp);
    % ecart type du residu epsilon
    res(floor((k-1)/nb)+1)=sqrt(sum(epsilon.^2)/length(epsilon));
    
% 
%     M=matx*matx';%Matrice des produits scalaires de x_i
%     V=M(2:p+1,1);
%     L=M(2:p+1,2:p+1);
%     a1=-L^(-1)*V;
%     a=[1;a1]; %Dans le poly a est un vecteur ligne, ici c'est un vecteur colonne
%     
%     out(:,floor((k-1)/nb)+1)=a;
%     etr(floor((k-1)/nb+1))=sqrt((a'*M*a)/nb);%�cart-type du residu
%   
end


    
