function h=lpc_morceau(p,x);
% Renvoie un filtre de taille p+1 dont la premi�re valeur est 1 et qui
% minimise le h*x

xmat=zeros(p+1,length(x)+p); 
for k=0:p
    xmat(k+1,k+1:k+length(x))=x;
end

M=xmat*(xmat');
L=M(2:end,2:end);
V=M(2:p+1,1);
h1=-L^(-1)*V;
h=[1;h1];
h=h';% On se remet en ligne
