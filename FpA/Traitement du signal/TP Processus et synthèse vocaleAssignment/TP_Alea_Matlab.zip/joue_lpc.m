function joue_lpc(lpcs,res,nb,Fe);
% On va rejouer un son dont on ne connait que les LPC et les normes 
% des r�sidus 

%Fabrication du signal

out=zeros(1,nb*size(lpcs,2));
for k=1:size(lpcs,1)
   
    sig=res(k)*randn(1,nb);
   
    out((k-1)*nb+1:k*nb)=filter(1,lpcs(k,:),res(k)*sig);
end

soundsc(out,Fe);
