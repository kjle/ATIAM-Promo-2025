function [h]=moindres_carres(p,x,z)
% Cette fonction renvoie simplement le filtre h qui minimise l'�nergie de 
% z-h*x    (h*x est la convolution PAS LE PRODUIT de h et x)
% h est de taille p+1
% Si la taille de z n'est pas suffisante, le programme se permet de tronquer
% les signaux en cons�quence.
% x et z sont traites comme des signaux causaux



%On et x et z sous la forme ligne
x=x(:); %on est sur d'avoir une colonne
x=x'; % et maintenant une ligne
z=z(:);
z=z';


%Nous commen�ons par construire une matrice rectangulaire xmat
% Cette matrice v�rifiera que si h est un vecteur ligne alors
% h*x=h.xmat (h est le produit matriciel)
% xmat est donc constitu�e de lignes qui sont de d�cal�es de x
xmat=zeros(p+1,length(x)+p); 
for k=0:p
    xmat(k+1,k+1:k+length(x))=x;
end

% que faire si la longueur de z ne correspond pas � celle de h*x?
%Si z est trop long, on le tronque
if length(z)>length(x)+p
    z=z(1:length(x));
end
% Si z est trop court, on le compl�te par des z�ros
if length(z)<length(x)+p
    z=[z zeros(1,length(x)+p-length(z))];
end

% R�solution de probl�me: Trouver h tel que || z-h.xmat|| est minimale
% Il n'est pas indispensable de comprendre la formule, m�me si pouvez essayer de
% le faire hors du TP.

%Calculs pr�liminaires
L=xmat*(xmat');
V=xmat*z';
% La solution au probl�me est
h=L^(-1)*V;
h=h'; % pour se remettre en ligne
