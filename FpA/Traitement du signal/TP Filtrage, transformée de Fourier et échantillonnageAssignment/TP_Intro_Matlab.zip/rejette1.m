function sortie=rejette1(entree,f0,Fs);

z0=exp(2*i*pi*f0/Fs); % position sur le cercle unite de la fréquence a éliminer

sortie=filter([1 -z0],1,entree); %elimination de la fréquence f0

sortie=filter([1 -conj(z0)],1,sortie); %Le signal est reel, il faut donc éliminer -f0 aussi!
 
% pour le calcul de la TZ, n'oubliez pas que les TZ se multiplient lorsque un
% signal est traite successivement par plusieurs filtres...

sortie=real(sortie);% En raison d'erreurs d'arrondi il peut subsister une partie imaginaire


