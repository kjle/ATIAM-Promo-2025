function sortie=rejette2(entree,f0,Fs,rho);
%valeur recommandée pour rho: au moins 0.9 et jamais plus de 1

z0=exp(2*i*pi*f0/Fs); % position sur le cercle unite de la fréquence a éliminer

sortie=filter([1 -z0],[1 -rho*z0],entree); 

sortie=filter([1 -conj(z0)],[1 -rho*conj(z0)],sortie); %Le signal est reel, il faut donc éliminer -f0 aussi!
 
% pour le calcul de la TZ, n'oubliez pas que les TZ se multiplient lorsque un
% signal est traite successivement par plusieurs filtres...

sortie=real(sortie);% En raison d'erreurs d'arrondi il peut subsister une partie imaginaire


