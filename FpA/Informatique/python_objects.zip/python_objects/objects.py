import miditools
from miditools import open_seq, play_seq,add_note


class musObj:
    pass
    




class basicMusObj(musObj):
    def __init__(self, d):
        self.dur  = d
        
    def get_duration(self):
        return self.dur
   
class note(basicMusObj):
    def __init__(self, p, v, d):
        basicMusObj.__init__(self,d)
        self.pitch = p
        self.vel = v
    
    def add_to_seq(self, seq, at):
        add_note(seq, at, self.dur, self.pitch, self.vel)
    
    def transpose (self,tones):
        self.pitch = self.pitch + tones
    
    def clone (self):
        return note(self.pitch,self.vel,self.dur)
        

class pause(basicMusObj):
    def add_to_seq(self, seq, at):
        pass
    
    def clone (self):
        return pause(self.dur)
    
    def transpose (self,tones):
        pass
        
class commpoundMusObj(musObj):
    # Constructor
    def __init__(self, elems):
        self.elements = elems
        
    def transpose (self,tones):
        for item in self.elements:
            item.transpose(tones)
        
class sequential(commpoundMusObj):
    #def __init__(self, elems):
    #    commpoundMusObj.__init__(self,elems)
        
    def get_duration(self):
        rep = 0
        for item in self.elements:
            rep = rep + item.get_duration()
        return rep
    
    def add_to_seq(self, seq, at):
        date = at
        for item in self.elements:
            item.add_to_seq (seq,date)
            date = date + item.get_duration()
        return None
    
    def clone (self):
        elems = []
        for item in self.elements:
            elems.append(item.clone())
        return sequential (elems)

class parallel(commpoundMusObj):
        
    def get_duration(self):
        rep = 0
        for item in self.elements:
            rep = max (rep, item.get_duration())
        return rep
    
    def add_to_seq(self, seq, at):
        for item in self.elements:
            item.add_to_seq (seq,at)
        return None
    
    def clone (self):
        elems = []
        for item in self.elements:
            elems.append(item.clone())
        return parallel (elems)
    


def play (obj):
    seq,midiout = open_seq()
    obj.add_to_seq (seq,0)
    play_seq(seq,midiout, obj.get_duration())



voice1 = sequential([note(60,80,1000),note(64,80,500),note(62,80,500),pause(1000),
                     note(67,80,1000)])
voice2 = sequential([note(52,80,2000),note(55,80,1000),note(55,80,1000)])

exemple1 = parallel([voice1,voice2])
exemple3 = exemple1.clone()
exemple3.transpose(12)

exemple2 = sequential([exemple1,pause(1000),exemple3])

def canon (obj,delta):
    return parallel ([obj, sequential([pause(delta), obj])])



play (canon (exemple2, 1000))


    
    